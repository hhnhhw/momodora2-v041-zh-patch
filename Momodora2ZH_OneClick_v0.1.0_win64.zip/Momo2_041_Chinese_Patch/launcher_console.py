"""Console mode wrapper for installer integration and automated verification."""
import launcher

if __name__ == "__main__":
    launcher.main()
