@echo off
cd /d "%~dp0"
if not exist "%~dp0Momodora2ZH_Setup.exe" (
  echo Momodora2ZH_Setup.exe is missing. Download the complete installer package.
  pause
  exit /b 1
)
start "" "%~dp0Momodora2ZH_Setup.exe"
